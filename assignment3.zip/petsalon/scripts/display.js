
function displayPetNames() {
    let petList = document.getElementById('pets');
    petList.innerHTML = "petList";
    salon.pets.forEach(pet => {
        petList.innerHTML += `<p>${pet.name}</p>`;
    });
    document.getElementById('totalPets').innerHTML = `Total: ${salon.pets.length}`;

}


function displayPetCards(){
    getE('pets').innerHTML="";
    let card="";
    for(let i=0;i<salon.pets.length;i++){
        let pet = salon.pets[i];
        card+=`
        <div class="petcard">
        <p>Name: ${pet.name}</p>
        <p>Age: ${pet.age}</p>
        <p>Gender: ${pet.gender}</p>
        <p>Breed: ${pet.breed}</p>
        <p>Service: ${pet.service}</p>
        <p>Type: ${pet.type}</p>
        
        </div>`;
}
getE('pets').innerHTML=card;
}