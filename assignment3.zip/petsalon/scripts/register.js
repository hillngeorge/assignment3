

//constructor
class Pet {
    constructor(n, a, g, b, s, t) {
        this.name = n;
        this.age = a;
        this.gender = g;
        this.breed = b;
        this.service = s;
        this.type = t;
        }
}




// DOM elements
const info = document.getElementById("info");
// const petTotal = document.getElementById("pet-total");
// const petNames = document.getElementById("pet-names");
// Function to calculate and display the total number of pets
// function calculatePetTotal() {
//     petTotal.innerHTML = `<p>${salon.pets.length}</p>`;
// }

// calculatePetTotal();
// Function to display pet names

function getE(id){
    return document.getElementById(id);
}
//get elements from html

let inputName = getE("txtName");
let inputAge = getE("txtAge");
let inputGender = getE("txtGender");
let inputBreed = getE("txtBreed");
let inputService = getE("txtService");
let inputType = getE("txtType");

// Function to register a new pet
function register(){
    
    //1)getting value

    //2)create the newPet using the constructor
    let newPet = new Pet(inputName.value,inputAge.value,inputGender.value,inputBreed.value,inputService.value,inputType.value);
    //3 push the newPwet to the array
    salon.pets.push(newPet);
displayPetCards();
    
}
    //4 call the display function
    


// Initialize function
function init() {
    let pet1 = new Pet("scooby", 60, "Male", "Hound", "Grooming", "Dog");
    let pet2 = new Pet("scrappy", 50, "Male", "Hound", "Grooming", "Dog");
    let pet3 = new Pet("tiny", 40, "Male", "Hound", "Grooming", "Dog");
    salon.pets.push(pet1, pet2, pet3);

displayPetCards();
}

// Call the init function when the window is fully loaded
window.onload = init;

